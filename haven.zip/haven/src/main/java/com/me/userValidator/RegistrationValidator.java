package com.me.userValidator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.me.pojo.User;




public class RegistrationValidator implements Validator {

	@Override
	public boolean supports(Class<?> type) {
		// TODO Auto-generated method stub
        return User.class.isAssignableFrom(type);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
      ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "error-name", "Name cannot be empty");
      ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "error-username", "username cannot be empty");
     ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error-password", "password cannot be empty");
      try {
	        User user = (User) target;
	        if (!user.getEmail().matches("([a-zA-Z1-9.-_])*(@)([A-Za-z]+)(.com)")) {
	            errors.rejectValue("email","error-email", "This is not a valid email");
	        }
      }
      catch(NullPointerException e) {
      	System.out.println("In Validator "+ e);
      }
      

		
	}

}
