package com.me.userValidator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.me.pojo.User;




public class AptRegistrationValidator implements Validator {

	@Override
	public boolean supports(Class<?> type) {
		// TODO Auto-generated method stub
        return User.class.isAssignableFrom(type);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		

      ValidationUtils.rejectIfEmpty(errors, "apartmentName", "error-apartmentName", "Name cannot be empty");
      ValidationUtils.rejectIfEmpty(errors, "address", "error-address", "Address cannot be empty");
     ValidationUtils.rejectIfEmpty(errors, "location", "error-location", "City cannot be empty");
   //  ValidationUtils.rejectIfEmpty(errors, "owner", "error-owner", "Owner cannot be empty");
     ValidationUtils.rejectIfEmpty(errors, "rent", "error-rent", "rent cannot be empty");
   //  ValidationUtils.rejectIfEmpty(errors, "description", "error-description", "description cannot be empty");
  //   ValidationUtils.rejectIfEmpty(errors, "status", "error-status", "Apartment availability cannot be empty");
   //  ValidationUtils.rejectIfEmpty(errors, "imageFile", "error-imageFile", "Apartment image cannot be empty");	
	}
   
}
