package com.me.userValidator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.me.pojo.User;




public class LoginValidator implements Validator {

	@Override
	public boolean supports(Class<?> type) {
		// TODO Auto-generated method stub
        return User.class.isAssignableFrom(type);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
      ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "error-username", "username cannot be empty");
     ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error-password", "password cannot be empty");
		
	}

}
