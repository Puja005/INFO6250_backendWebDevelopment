package com.me.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.MapKey;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.NaturalId;
import org.springframework.lang.NonNull;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table
public class User {
		@Id
		@GeneratedValue (strategy = GenerationType.IDENTITY)
		private int userid;
		@NaturalId
		@NonNull
		private String username;
		@NonNull
		private String name;
		@NonNull
		private String email;
		@NonNull
		private String password;
		private String dateOfRegistration;
		@OneToMany(mappedBy="viewer")
		private Set<Apartment> apartmentViewList;
		@OneToMany(mappedBy="owner")
		private Set<Apartment> apartmentPostList;

		public User() {
			this.dateOfRegistration = String.valueOf(new Date());
			this.apartmentViewList= new HashSet<Apartment>();
			this.apartmentPostList= new HashSet<Apartment>();
	}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		public String getDateOfRegistration() {
			return dateOfRegistration;
		}
		public void setDateOfRegistration(String dateOfRegistration) {
			this.dateOfRegistration = dateOfRegistration;
		}
		
		public Set<Apartment> getApartmentViewList() {
			return apartmentViewList;
		}
		public void setApartmentViewList(Set<Apartment> apartmentViewList) {
			this.apartmentViewList = apartmentViewList;
		}
		
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		
		public int getUserid() {
			return userid;
		}
		public void setUserid(int userid) {
			this.userid = userid;
		}
		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return this.name;
		}
		public Set<Apartment> getApartmentPostList() {
			return apartmentPostList;
		}
		public void setApartmentPostList(Set<Apartment> apartmentPostList) {
			this.apartmentPostList = apartmentPostList;
		}
			public void addToApartmentViewList(Apartment apartment) {
			apartmentViewList.add(apartment);

		}
		public void removeFromApartmentViewList(Apartment apartment) {
			apartmentViewList.remove(apartment);

		}
		public void addToApartmentPostList(Apartment apartment) {
			apartmentPostList.add(apartment);

		}
		public void removeFromApartmentPostList(Apartment apartment) {
			apartmentPostList.remove(apartment);

		} 
		
	}


