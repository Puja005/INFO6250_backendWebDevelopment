package com.me.pojo;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.web.multipart.MultipartFile;

import org.springframework.stereotype.Component;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.transaction.Transactional;


@Component
@Entity
@Transactional
public class Apartment {
		
		@Id
		@GeneratedValue
		private int apartmentId;

		private String apartmentName;

		@ManyToOne
		private User owner;
		@Column(columnDefinition="TEXT")
		private String description;
		private float rating; 
		private String postDate; 
		private String status;
		private String location;
		private String address;
		private float rent;
		
		@ManyToOne(fetch = FetchType.LAZY )
		private User viewer;
			

		@Transient
		private MultipartFile imageFile;
		private String image;
		
		
		public Apartment() {
		}
		public int getApartmentId() {
			return apartmentId;
		}
		public void setApartmentId(int apartmentId) {
			this.apartmentId = apartmentId;
		}
		
		public MultipartFile getImageFile() {
			return imageFile;
		}
		public void setImageFile(MultipartFile imageFile) {
			this.imageFile = imageFile;
		}
		
		public String getApartmentName() {
			return apartmentName;
		}
		public void setApartmentName(String apartmentName) {
			this.apartmentName = apartmentName;	
		}

		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public float getRating() {
			return rating;
		}
		public void setRating(float rating) {
			this.rating = rating;
		}
		public String getPostDate() {
			return postDate;
		}
		public void setPostDate(String postDate) {
			this.postDate = postDate;
		}
				

		public String getImage() {
			return image;
		}
		public void setImage(String image) {
			this.image = image;
		}
		public User getOwner() {
			return owner;
		}
		public void setOwner(User owner) {
			this.owner = owner;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public User getViewer() {
			return viewer;
		}
		public void setViewer(User viewer) {
			this.viewer = viewer;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public float getRent() {
			return rent;
		}
		public void setRent(float rent) {
			this.rent = rent;
		}
		
	}


