package com.me.test;

import com.me.dao.UserDao;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	UserDao userdao= new UserDao();
	//	User login= userdao.checkLogin("puja.k@northeastern.edu", "Student123");
	//	System.out.println(login.getUserId()+" "+ login.getEmail()+ " "+ login.getPassword());

	}

}
