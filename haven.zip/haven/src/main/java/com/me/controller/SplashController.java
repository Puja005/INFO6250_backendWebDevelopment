package com.me.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.me.dao.ApartmentDao;
import com.me.dao.UserDao;
import com.me.pojo.Apartment;
import com.me.pojo.User;


@Controller
public class SplashController {
	
	@GetMapping("/")
	public String getSplashPage(HttpServletRequest request) {
		return "splash";
	}

	@GetMapping("/home.htm")
	public String getHomePage(HttpServletRequest request) {
		return "splash";
	}
	
	@GetMapping("/login.htm")
	public String getLoginForm(ModelMap model, User user) {
		System.out.println("reaching login form");
		model.addAttribute(user);
		return "login-form" ;
	}
	
	@GetMapping("/registration.htm")	
	public String getRegistrationForm(ModelMap model, User user) {
		model.addAttribute(user);
		return "registration";
	}
	
	@GetMapping("/addApartment.htm")
	public String addApartmentPost(HttpServletRequest request,ModelMap model, UserDao userDao, Apartment apartment) {
		if (request.getSession(false)==(null)) {
		return "error-page" ;}
		model.addAttribute(apartment);
		return "addApartment" ;
	}
	
	@GetMapping("/viewPost.htm")
	public String viewApartmentPost(HttpServletRequest request, ApartmentDao apartmentDao) {
		if (request.getSession(false)==(null)) {
			return "splash";
		}
		try {
		List<Apartment> apartments=apartmentDao.list();
		request.setAttribute("apartments", apartments);
		return "viewApartment" ;} catch (Exception e){
			return "error-page";
		}
	}
	
	@GetMapping("/search.htm")
	public String searchApartment(HttpServletRequest request, ApartmentDao apartmentDao) {
		String city= request.getParameter("location");
		float rent=0;
		System.out.println(city);
		if (request.getParameter("rent")!="") {
		rent=Float.parseFloat(request.getParameter("rent"));
		}
		if (city=="") {
		List<Apartment> apartments=apartmentDao.filterByRent(rent);
		request.setAttribute("apartments", apartments);
		return "viewApartment" ;
		}
		List<Apartment> apartments=apartmentDao.filterApartment(city, rent);
		request.setAttribute("apartments", apartments);
		return "viewApartment" ;
	}
	
	@GetMapping("/apartmentDetail{apartmentId}")
	public String loadApartmentDetailPage(@PathVariable int apartmentId, HttpServletRequest request,ApartmentDao apartmentDao) {
		Apartment apartment = apartmentDao.getApartmentById(apartmentId);
		request.setAttribute("apartment", apartment);
		return "apartmentDetail";
	}
	
}
