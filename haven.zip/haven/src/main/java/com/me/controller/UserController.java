package com.me.controller;


import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.me.dao.ApartmentDao;
import com.me.dao.UserDao;
import com.me.pojo.Apartment;
import com.me.pojo.User;
import com.me.userValidator.LoginValidator;
import com.me.userValidator.RegistrationValidator;

import java.util.List;
import java.util.Set;

import javax.servlet.http.*;

@Controller
public class UserController {
    
	@PostMapping("/login.htm")
	public ModelAndView checkLoginUser(@ModelAttribute("user") User user, BindingResult result, SessionStatus status, HttpServletRequest request, HttpServletResponse response, UserDao userdao,LoginValidator validator) throws Exception{
		validator.validate(user,result);
		if (result.hasErrors()) {
			return new ModelAndView("login-form"); 
		}
		String username= request.getParameter("username");
		String psw = request.getParameter("password");
		HttpSession session = request.getSession();
        user= userdao.checkLogin(username, psw);
		if (user!=null) {
			System.out.println(request.getRequestedSessionId());
			session.setAttribute("user", user);
			return new ModelAndView("splash");
		}
		return new ModelAndView("error-page");	
	}
	
	
	@PostMapping("/registration.htm")
		public ModelAndView register(@ModelAttribute("user") User user, BindingResult result, SessionStatus status, HttpServletRequest request, HttpServletResponse response, UserDao userdao,RegistrationValidator validator) throws Exception{
		String username =user.getUsername().toLowerCase();
		validator.validate(user,result);
		if (result.hasErrors()) {
			return new ModelAndView("registration"); 
		}
		if(userdao.get(username)==null) {
			userdao.save(user);
			HttpSession session= request.getSession();
			session.setAttribute("user", user);
			return new ModelAndView("splash");
	}
		return new ModelAndView("error-page"); }
	
	@GetMapping("/logout.htm")
	public ModelAndView logout(HttpServletRequest request,User user) {
		System.out.println(request.getRequestedSessionId());
		HttpSession session= request.getSession();
        session.invalidate();
		return new ModelAndView("login-form");
	}
	
	@GetMapping("/myProfile{userid}.htm")
    public String getUserProfile(@PathVariable int userid, HttpServletRequest request,UserDao userdao) {
		User user=(User) userdao.get(userid);
		if(user!=null) {
     	request.setAttribute("thisuser", user);
		Set<Apartment> myApartmentPosts=user.getApartmentPostList();
		request.setAttribute("myApartmentPosts", myApartmentPosts);
		return "userProfile";}
		return "error-page";
	}
	
	@GetMapping("/favouriteApartment{apartmentId}")
	public ModelAndView addToFavourite(@PathVariable int apartmentId, HttpServletRequest request,UserDao userdao, ApartmentDao apartmentDao) {
		User user=(User) request.getSession().getAttribute("user");
	    Apartment apartment=apartmentDao.getApartmentById(apartmentId);
	    if (apartment.getViewer()==null) {
	    	apartment.setViewer(user);
		    apartmentDao.update(apartment);
	    	user.addToApartmentViewList(apartment);
			request.setAttribute("myApartmentPosts", user.getApartmentViewList());
			return new ModelAndView("success");}

	    if (user.getUserid()!=(apartmentDao.getApartmentViewer(apartmentId).getUserid())) {
	    	apartment.setViewer(user);
		    apartmentDao.update(apartment);
	    	user.addToApartmentViewList(apartment);
			request.setAttribute("myApartmentPosts", user.getApartmentViewList());
			return new ModelAndView("success");

	    }
		 return new ModelAndView("error-page");
	}
	
	
	@GetMapping("/viewFavouriteApartment.htm")
	public ModelAndView viewFavourite(HttpServletRequest request) {
		User user=(User) request.getSession().getAttribute("user");
		if (user !=null) {
		request.setAttribute("myApartmentPosts", user.getApartmentViewList());
		return new ModelAndView ("favouriteApartment");}
		
		return new ModelAndView ("error-page");
	}
}


