package com.me.controller;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;


import com.me.pojo.Apartment;
import com.me.pojo.User;
import com.me.userValidator.AptRegistrationValidator;
import com.me.dao.ApartmentDao;
import com.me.dao.UserDao;


@Controller
public class ApartmentController {
	
	@PostMapping("/addApartmentPost.htm")
	public ModelAndView addApartment(@ModelAttribute("apartment") Apartment apartment, BindingResult result, SessionStatus status, HttpServletRequest request, HttpServletResponse response, ApartmentDao apartmentDao, UserDao userdao) throws Exception{
	String fileName="img"+System.currentTimeMillis()+"-"+ new Random().nextInt(10000)+ new Random().nextInt(10000)+".jpg";
	apartment.setImage(fileName);
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date date = new Date();
	String postDate= dateFormat.format(date);
	apartment.setPostDate(postDate);
	HttpSession session=request.getSession(false);
	User ownerObj=(User)session.getAttribute("user");
	apartment.setOwner(ownerObj);
	if(apartmentDao.get(apartment.getApartmentName())==null) {

		apartmentDao.save(apartment);
		ownerObj.addToApartmentPostList(apartment);
		try {
			apartment.getImageFile().transferTo(new File("/Users/siaap/Downloads/haven/src/main/webapp/images/"+fileName));
		}
		catch(IllegalStateException e) {
			System.out.println("IllegalStateException: " + e.getMessage());
		}
		return new ModelAndView("splash");
	}
	return new ModelAndView("error-page");
	
	}
	
    @GetMapping("/deleteApartment{apartmentId}")
    public ModelAndView deleteApartmentPost(@PathVariable int apartmentId, HttpServletRequest request,ApartmentDao apartmentDao) {
	    Apartment apartment=apartmentDao.getApartmentById(apartmentId);
	    User user=apartmentDao.getApartmentOwner(apartmentId);
	    apartmentDao.delete(apartment);
		Set<Apartment> myApartmentPosts=user.getApartmentPostList();
		request.setAttribute("myApartmentPosts", myApartmentPosts);
    	return new ModelAndView("userProfile");
}
    @PostMapping("/updateApartment{apartmentId}")
    public ModelAndView updateApartmentPost(@PathVariable int apartmentId,@ModelAttribute("apartment") Apartment apartment, BindingResult result, SessionStatus status, HttpServletRequest request, HttpServletResponse response, ApartmentDao apartmentDao,UserDao userdao) throws IOException {
    	String fileName="img"+System.currentTimeMillis()+"-"+ new Random().nextInt(10000)+ new Random().nextInt(10000)+".jpg";
    	apartment.setImage(fileName);
    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    	Date date = new Date();
    	String postDate= dateFormat.format(date);
    	apartment.setPostDate(postDate);
    	HttpSession session=request.getSession(false);
    	User ownerObj=(User)session.getAttribute("user");
    	apartment.setOwner(ownerObj);
		if(apartmentDao.getApartmentById(apartmentId)!=null) {
			apartmentDao.update(apartment);
    		try {
    			apartment.getImageFile().transferTo(new File("/Users/siaap/Downloads/haven/src/main/webapp/images/"+fileName));
    		}
    		catch(IllegalStateException e) {
    			System.out.println("IllegalStateException: " + e.getMessage());
    		}
    		return new ModelAndView("success");
		}
		return new ModelAndView("error-page");
}
    
    
    @GetMapping("/updateApartment{apartmentId}")
    public ModelAndView updateApartment(@PathVariable int apartmentId, HttpServletRequest request,ApartmentDao apartmentDao,ModelMap model) {
	    Apartment apartment=apartmentDao.getApartmentById(apartmentId);
	    model.addAttribute("apartment", apartment);
	    request.setAttribute("apt", apartment);
    	return new ModelAndView("updateApartment");
}
}
