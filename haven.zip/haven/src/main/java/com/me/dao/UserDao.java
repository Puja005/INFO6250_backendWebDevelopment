package com.me.dao;

import com.me.pojo.User;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;



public class UserDao extends DAO {

	public void save(User user){
        begin();
        getSession().save(user);
        commit();
        close();
    }
    public void delete(User user){
        begin();
        getSession().delete(user);
        commit();
        close();
    }
    
    public void update(User user){
        begin();
        getSession().update(user);
        commit();
        close();
    }
    
   
    
    public User checkLogin(String username,String psw) {
 	  // Query query= getSession().getNamedQuery("checkLogin");
 	   //query.setString("email", user);
 	   //query.setString("password",psw);
 	   //return (UserLogin) query.uniqueResult();
 	   
 	   Criteria crit= getSession().createCriteria(User.class);
 	 //  Criterion c1= Restrictions.eq("username",username);
 	  // Criterion c2= Restrictions.eq("password",psw);
 	   crit.add(Restrictions.eq("username",username));
 	  crit.add(Restrictions.eq("password",psw));
 	  // crit.add(c1);
 	  // crit.add(c2);
 	   return (User) crit.uniqueResult();

    }
    
    public User get(String username){
    	try {
    		begin();
            Query query=getSession().createQuery("FROM User where username=:username");
            query.setParameter("username", username);
            User user= (User) query.uniqueResult();
            close();
            return user;
        } catch (HibernateException e) {
            rollback();
            Logger.getAnonymousLogger().log(Level.WARNING, "Cannot close", e);
            return null;
        }

    }
    
    public List<User> listPostOwners(){
    	begin();
    	Query<User> query = getSession().createQuery("FROM User where role is not null");
		List<User> list = query.list();
		close();
		return list;
    }
    
    public User get(int id){
    	try {
    		begin();
	        User user=(User) getSession().get(User.class,id);
	        close();
	        return user; 
        } catch (HibernateException e) {
            rollback();
            Logger.getAnonymousLogger().log(Level.WARNING, "Cannot close", e);
            return null;
        }
    }


}
