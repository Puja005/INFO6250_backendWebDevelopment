package com.me.dao;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.query.Query;

import com.me.pojo.Apartment;
import com.me.pojo.User;

public class ApartmentDao extends DAO {

	public void save(Apartment apartment){
        begin();
        getSession().save(apartment);
        commit();
        close();
    }
    public void delete(Apartment apartment){
        begin();
        getSession().delete(apartment);
        commit();
        close();
    }
    
    public void update(Apartment apartment){
        begin();
        getSession().update(apartment);
        commit();
        close();
    }
    
    public void evict(Apartment apartment) {
    	begin();
        getSession().evict(apartment);
        commit();
        close();
    }
    
    
    public Apartment get(String name){
    	try {
            begin();
            Query query=getSession().createQuery("FROM Apartment where apartmentName=:name");
            query.setParameter("name", name);
            Apartment apartment= (Apartment) query.uniqueResult();
            close();
            return apartment;
        } catch (HibernateException e) {
            rollback();
            Logger.getAnonymousLogger().log(Level.WARNING, "Cannot close", e);
            return null;
        }
    }
    public Apartment getApartmentById(int id){
    	try {
            begin();
            Apartment apartment=(Apartment) getSession().get(Apartment.class,id);
            close();
            return apartment;
        } catch (HibernateException e) {
            rollback();
            Logger.getAnonymousLogger().log(Level.WARNING, "Cannot close", e);
            return null;
        }

    }

    public Apartment getApartmentByName(String apartmentName){
    	try {
            begin();
            Query query=getSession().createQuery("FROM Apartment where apartmentName=:apartmentName");
            query.setParameter("apartmentName", apartmentName);
            Apartment apartment= (Apartment) query.uniqueResult();
            close();
            return apartment;
        } catch (HibernateException e) {
            rollback();
            Logger.getAnonymousLogger().log(Level.WARNING, "Cannot close", e);
            return null;
        }
    }
    public List<Apartment> list() {
    	begin();
		Query<Apartment> query = getSession().createQuery("FROM Apartment");
		List<Apartment> list = query.list();
		close();
		return list;
	}
    
    public List<Apartment> filterApartment(String city,float rental) {
    	begin();
    	String hql = "FROM Apartment WHERE location=:location AND rent>:rental Order by rent ";
		Query query = getSession().createQuery(hql);
		query.setParameter("location", city);
		query.setParameter("rental", rental);
		List result = query.list();
		close();
		return result;
	}
    
    public List<Apartment> filterByRent(float rental) {
    	begin();
    	String hql = "From Apartment where rent> :rental order by rent";
		Query query = getSession().createQuery(hql);
		query.setParameter("rental", rental);
		List result = query.list();
		close();
		return result;
	}
    
    public User getApartmentOwner(int apartmentId){
    	try {
            begin();
            Query query=getSession().createQuery("Select owner FROM Apartment where apartmentId=:apartmentId");
            query.setParameter("apartmentId", apartmentId);
            User user= (User) query.uniqueResult();
            close();
            return user;
        } catch (HibernateException e) {
            rollback();
            Logger.getAnonymousLogger().log(Level.WARNING, "Cannot close", e);
            return null;
        }    }
    
    public User getApartmentViewer(int apartmentId){
    	try {
            begin();
            Query query=getSession().createQuery("Select viewer FROM Apartment where apartmentId=:apartmentId");
            query.setParameter("apartmentId", apartmentId);
            User user= (User) query.uniqueResult();
            close();
            return user;
        } catch (HibernateException e) {
            rollback();
            Logger.getAnonymousLogger().log(Level.WARNING, "Cannot close", e);
            return null;
        }    }
}
